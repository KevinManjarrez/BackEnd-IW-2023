import * as pedidoService from '../services/pedido.service';

// GET************************************************************************************************ */

export const getPedidosAll = async(req, res, next) => {
    try{
        const pedidosAll = await pedidoService.getPedidosAll();
        if(pedidosAll) {
            return res.status(pedidosAll.status).json(pedidosAll);
        }
    }catch(error){
        next(error);
    }
};

// POST********************************************************************************************** */
export const addPedidos = async(req, res, next) => {
    try{
        const pedidosAdded = await pedidoService.addPedidos(req.body);
        
        if(pedidosAdded) {
            return res.status(pedidosAdded.status).json(pedidosAdded);
        }
    }catch(error){
        next(error);
    }
};
// FIN POST*************************************************************************************** */

// PUT*********************************************************************************************** */
export const updatePedido = async (req, res, next) => {
    try {
        const { id } = req.params; // Obtén el ID de la entrega desde los parámetros de la solicitud
        const newData = req.body; // Obtén los nuevos datos desde el cuerpo de la solicitud

        const result = await pedidoService.updatePedido(id, newData);

        if (result.status === 200) {
            return res.status(200).json(result);
        } else if (result.status === 404) {
            return res.status(404).json(result);
        }
    } catch (error) {
        next(error);
    }
};
// FIN PUT********************************************************************************************* */

// DELETE************************************************************************************************ */
export const deletePedidoByValue = async (req, res, next) => {
    try {
      const { id } = req.params; // Obtén el id del Pedido para eliminar
      
      // Llama al servicio de eliminación y pasa el valor a eliminar
      const result = await pedidoService.deletePedidoByValue(id);
  
      return res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  };
// FIN DELETE********************************************************************************************* */