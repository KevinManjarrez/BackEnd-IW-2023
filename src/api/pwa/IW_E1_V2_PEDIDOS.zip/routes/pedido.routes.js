import { Router } from "express";
import * as pedidoController from '../controllers/pedido.controller';

const router = Router();

router.get('/', pedidoController.getPedidosAll);
router.post('/', pedidoController.addPedidos);
router.put('/:id', pedidoController.updatePedido);
router.delete('/:id', pedidoController.deletePedidoByValue);

export default router;